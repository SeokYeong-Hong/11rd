
package com.example.a11rd

import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 변수 선언 및 ID 연결

        val mainSnail = findViewById<ImageView>(R.id.mainSnail)
        val selectedShell = findViewById<ImageView>(R.id.selectedShell)

        val shell1 = findViewById<ImageView>(R.id.shell1)
        val shell2 = findViewById<ImageView>(R.id.shell2)
        val shell3 = findViewById<ImageView>(R.id.shell3)
        val shell4 = findViewById<ImageView>(R.id.shell4)

        // 메인 달팽이 이미지 설정
        mainSnail.setImageResource(R.drawable.snail5)

        // 1번 클릭
        shell1.setOnClickListener {
            selectedShell.setImageResource(R.drawable.snail1)
            selectedShell.visibility = ImageView.VISIBLE

            Toast.makeText(this, "오답입니다", Toast.LENGTH_SHORT).show()
        }

        // 2번 클릭 (정답)
        shell2.setOnClickListener {
            selectedShell.setImageResource(R.drawable.snail2)
            selectedShell.visibility = ImageView.VISIBLE

            Toast.makeText(this, "정답입니다", Toast.LENGTH_SHORT).show()
        }

        // 3번 클릭
        shell3.setOnClickListener {
            selectedShell.setImageResource(R.drawable.snail3)
            selectedShell.visibility = ImageView.VISIBLE

            Toast.makeText(this, "오답입니다", Toast.LENGTH_SHORT).show()
        }

        // 4번 클릭
        shell4.setOnClickListener {
            selectedShell.setImageResource(R.drawable.snail4)
            selectedShell.visibility = ImageView.VISIBLE

            Toast.makeText(this, "오답입니다", Toast.LENGTH_SHORT).show()
        }
    }
}
